// js-license
"use strict";function MyClass(){this.hoge=function(){},this.fuga=10}var addition=function(a,b){return a+b},drop=function(a,b){return a-b};!function(){console.log("test")}();